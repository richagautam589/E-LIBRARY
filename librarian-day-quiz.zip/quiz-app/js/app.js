/* ===================================================================
   The Stacks & The Screen — App Logic
   =================================================================== */

const LS_THEME = "nld_theme";
const LS_LEADERBOARD = "nld_leaderboard";
const QUESTION_TIME = 30; // seconds per question

const TYPE_LABELS = { mcq: "Multiple Choice", picture: "Identify the Picture", situation: "Situation Based" };

/* ------------------------------ STATE -------------------------------- */
let state = {
  playerName: "",
  quiz: [],
  index: 0,
  score: 0,
  streak: 0,
  bestStreak: 0,
  perCategory: {}, // {resources: {correct, total}, ...}
  answered: false,
  startTime: null,
  timerHandle: null,
  timeLeft: QUESTION_TIME,
};

/* ------------------------------ ELEMENTS ------------------------------ */
const screens = {
  start: document.getElementById("screen-start"),
  quiz: document.getElementById("screen-quiz"),
  result: document.getElementById("screen-result"),
  leaderboard: document.getElementById("screen-leaderboard"),
};

function showScreen(name) {
  Object.values(screens).forEach((s) => s.classList.remove("active"));
  screens[name].classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

/* ------------------------------ THEME ---------------------------------- */
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(LS_THEME, theme);
}
(function initTheme() {
  const saved = localStorage.getItem(LS_THEME);
  applyTheme(saved || "opac");
})();
document.getElementById("themeToggle").addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme");
  applyTheme(current === "opac" ? "catalog" : "opac");
});

/* ------------------------------ FLOATERS (ambient bg) ------------------ */
(function spawnFloaters() {
  const wrap = document.getElementById("floaters");
  const glyphs = ["📖", "📚", "🔖", "🗂️", "💻", "🔍"];
  for (let i = 0; i < 14; i++) {
    const el = document.createElement("span");
    el.className = "floater";
    el.textContent = glyphs[i % glyphs.length];
    el.style.left = Math.random() * 100 + "%";
    el.style.animationDuration = 18 + Math.random() * 22 + "s";
    el.style.animationDelay = -(Math.random() * 30) + "s";
    el.style.fontSize = 1 + Math.random() * 1.4 + "rem";
    wrap.appendChild(el);
  }
})();

/* ------------------------------ START FLOW ------------------------------ */
document.getElementById("nameForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("playerName").value.trim();
  state.playerName = name || "Reader";
  startQuiz();
});

document.getElementById("leaderboardNavBtn").addEventListener("click", () => {
  renderLeaderboard();
  showScreen("leaderboard");
});
document.getElementById("backToStartBtn").addEventListener("click", () => showScreen("start"));
document.getElementById("viewLeaderboardBtn").addEventListener("click", () => {
  renderLeaderboard();
  showScreen("leaderboard");
});
document.getElementById("retryBtn").addEventListener("click", startQuiz);
document.getElementById("clearLeaderboardBtn").addEventListener("click", () => {
  if (confirm("Clear all leaderboard entries on this device?")) {
    localStorage.removeItem(LS_LEADERBOARD);
    renderLeaderboard();
  }
});

/* ------------------------------ QUIZ SETUP ------------------------------ */
function startQuiz() {
  state.quiz = buildShuffledQuiz();
  state.index = 0;
  state.score = 0;
  state.streak = 0;
  state.bestStreak = 0;
  state.answered = false;
  state.startTime = Date.now();
  state.perCategory = {};
  Object.keys(CATEGORY_META).forEach((c) => (state.perCategory[c] = { correct: 0, total: 0 }));

  buildDrawerTabs();
  document.getElementById("scoreValue").textContent = "0";
  showScreen("quiz");
  renderQuestion(false);
}

function buildDrawerTabs() {
  const wrap = document.getElementById("drawerTabs");
  wrap.innerHTML = "";
  state.quiz.forEach((q, i) => {
    const tab = document.createElement("div");
    tab.className = "drawer-tab";
    tab.id = "tab-" + i;
    tab.textContent = (i + 1).toString().padStart(2, "0");
    wrap.appendChild(tab);
  });
}

function updateDrawerTabs() {
  state.quiz.forEach((q, i) => {
    const tab = document.getElementById("tab-" + i);
    tab.classList.remove("done", "current");
    if (i < state.index) tab.classList.add("done");
    else if (i === state.index) tab.classList.add("current");
  });
}

/* ------------------------------ RENDER QUESTION -------------------------- */
function renderQuestion(animate) {
  const q = state.quiz[state.index];
  const card = document.getElementById("questionCard");
  state.answered = false;

  const doRender = () => {
    document.getElementById("qCounter").textContent = `Question ${state.index + 1} / ${state.quiz.length}`;
    const meta = CATEGORY_META[q.category];
    document.getElementById("catBadge").textContent = `${meta.icon} ${meta.label}`;
    document.getElementById("cardTab").textContent = `${meta.tab} · ${(state.index + 1).toString().padStart(2, "0")}`;
    document.getElementById("qTypeBadge").textContent = TYPE_LABELS[q.type] || "Question";
    document.getElementById("questionText").textContent = q.q;

    const illuSlot = document.getElementById("illustrationSlot");
    if (q.image) {
      illuSlot.innerHTML = q.image;
      illuSlot.hidden = false;
    } else {
      illuSlot.innerHTML = "";
      illuSlot.hidden = true;
    }

    const grid = document.getElementById("optionsGrid");
    grid.innerHTML = "";
    const letters = ["A", "B", "C", "D"];
    q.options.forEach((opt, i) => {
      const btn = document.createElement("button");
      btn.className = "option-btn";
      btn.type = "button";
      btn.dataset.value = opt;
      btn.innerHTML = `<span class="option-letter">${letters[i]}</span><span>${opt}</span>`;
      btn.addEventListener("click", () => selectAnswer(opt, btn));
      grid.appendChild(btn);
    });

    document.getElementById("feedbackPanel").hidden = true;
    document.getElementById("nextBtn").disabled = true;

    const progressFill = document.getElementById("progressFill");
    progressFill.style.width = `${((state.index) / state.quiz.length) * 100}%`;
    document.getElementById("progressBar").setAttribute("aria-valuenow", state.index + 1);

    updateDrawerTabs();
    startTimer();
  };

  if (animate) {
    card.classList.add("flip-out");
    setTimeout(() => {
      card.classList.remove("flip-out");
      doRender();
      card.classList.add("flip-in");
      setTimeout(() => card.classList.remove("flip-in"), 400);
    }, 300);
  } else {
    doRender();
  }
}

/* ------------------------------ TIMER ------------------------------------ */
const TIMER_CIRCUMFERENCE = 2 * Math.PI * 28;

function startTimer() {
  clearInterval(state.timerHandle);
  state.timeLeft = QUESTION_TIME;
  const ring = document.getElementById("timerRing");
  const arc = document.getElementById("timerArc");
  arc.style.strokeDasharray = TIMER_CIRCUMFERENCE;
  ring.classList.remove("warn");
  updateTimerDisplay();

  state.timerHandle = setInterval(() => {
    state.timeLeft -= 1;
    updateTimerDisplay();
    if (state.timeLeft <= 8) ring.classList.add("warn");
    if (state.timeLeft <= 0) {
      clearInterval(state.timerHandle);
      if (!state.answered) selectAnswer(null, null); // time's up
    }
  }, 1000);
}

function updateTimerDisplay() {
  document.getElementById("timerNum").textContent = Math.max(state.timeLeft, 0);
  const arc = document.getElementById("timerArc");
  const fraction = Math.max(state.timeLeft, 0) / QUESTION_TIME;
  arc.style.strokeDashoffset = TIMER_CIRCUMFERENCE * (1 - fraction);
}

/* ------------------------------ ANSWER HANDLING --------------------------- */
function selectAnswer(chosen, btnEl) {
  if (state.answered) return;
  state.answered = true;
  clearInterval(state.timerHandle);

  const q = state.quiz[state.index];
  const isCorrect = chosen === q.correct;
  const allBtns = document.querySelectorAll("#optionsGrid .option-btn");

  allBtns.forEach((b) => {
    b.disabled = true;
    if (b.dataset.value === q.correct) b.classList.add("correct");
    if (btnEl && b === btnEl && !isCorrect) b.classList.add("incorrect");
    if (btnEl && b === btnEl) b.classList.add("selected");
  });

  state.perCategory[q.category].total += 1;
  if (isCorrect) {
    state.perCategory[q.category].correct += 1;
    state.score += 1;
    state.streak += 1;
    state.bestStreak = Math.max(state.bestStreak, state.streak);
  } else {
    state.streak = 0;
  }
  document.getElementById("scoreValue").textContent = state.score;

  const panel = document.getElementById("feedbackPanel");
  const stamp = document.getElementById("stampMark");
  const heading = document.getElementById("feedbackHeading");
  const explain = document.getElementById("feedbackExplanation");

  stamp.classList.remove("wrong", "skip");
  if (chosen === null) {
    stamp.textContent = "TIME'S UP";
    stamp.classList.add("skip");
    heading.textContent = `The correct answer was: ${q.correct}`;
  } else if (isCorrect) {
    stamp.textContent = "CORRECT";
    heading.textContent = "Correct — well shelved!";
  } else {
    stamp.textContent = "INCORRECT";
    stamp.classList.add("wrong");
    heading.textContent = `Not quite. The correct answer: ${q.correct}`;
  }
  explain.textContent = q.explanation;
  panel.hidden = false;

  const nextBtn = document.getElementById("nextBtn");
  nextBtn.disabled = false;
  nextBtn.textContent = state.index === state.quiz.length - 1 ? "See Results →" : "Next Question →";
}

document.getElementById("nextBtn").addEventListener("click", () => {
  if (!state.answered) return;
  state.index += 1;
  if (state.index >= state.quiz.length) {
    finishQuiz();
  } else {
    renderQuestion(true);
  }
});

/* ------------------------------ RESULTS ----------------------------------- */
function finishQuiz() {
  const elapsedMs = Date.now() - state.startTime;
  const totalSeconds = Math.round(elapsedMs / 1000);
  const accuracy = Math.round((state.score / state.quiz.length) * 100);

  document.getElementById("resultName").textContent = state.playerName;
  document.getElementById("resultScoreBig").textContent = state.score;
  document.getElementById("resultCorrect").textContent = `${state.score}/${state.quiz.length}`;
  document.getElementById("resultAccuracy").textContent = `${accuracy}%`;
  document.getElementById("resultTime").textContent = formatTime(totalSeconds);
  document.getElementById("resultBestStreak").textContent = state.bestStreak;

  const verdicts = [
    [90, "Master Cataloguer — your knowledge belongs in the reference section!"],
    [70, "Skilled Librarian — a truly well-indexed mind."],
    [50, "Promising Page-Turner — a bit more browsing and you'll top the shelf."],
    [0, "Fresh off the Orientation Desk — every expert started here. Try again!"],
  ];
  const verdict = verdicts.find(([min]) => accuracy >= min)[1];
  document.getElementById("resultVerdict").textContent = verdict;

  const ringArc = document.getElementById("resultRingArc");
  const circumference = 2 * Math.PI * 52;
  ringArc.style.strokeDasharray = circumference;
  ringArc.style.strokeDashoffset = circumference;
  requestAnimationFrame(() => {
    ringArc.style.strokeDashoffset = circumference * (1 - accuracy / 100);
  });

  renderBreakdown();
  showScreen("result");
  launchConfetti();
  saveToLeaderboard(state.score, accuracy, totalSeconds);
}

function renderBreakdown() {
  const wrap = document.getElementById("categoryBreakdown");
  wrap.innerHTML = "";
  Object.entries(state.perCategory).forEach(([cat, data]) => {
    const meta = CATEGORY_META[cat];
    const pct = data.total ? (data.correct / data.total) * 100 : 0;
    const row = document.createElement("div");
    row.className = "breakdown-row";
    row.innerHTML = `
      <span class="breakdown-label">${meta.icon} ${meta.label}</span>
      <span class="breakdown-bar"><span class="breakdown-fill" style="width:0%"></span></span>
      <span class="breakdown-score">${data.correct}/${data.total}</span>`;
    wrap.appendChild(row);
    requestAnimationFrame(() => {
      row.querySelector(".breakdown-fill").style.width = pct + "%";
    });
  });
}

function formatTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

/* ------------------------------ CONFETTI ----------------------------------- */
function launchConfetti() {
  const zone = document.getElementById("confettiZone");
  zone.innerHTML = "";
  const colors = ["#d7b26a", "#37c9bd", "#ef6a5c", "#52d495", "#5fe6da"];
  for (let i = 0; i < 60; i++) {
    const piece = document.createElement("span");
    piece.className = "confetto";
    piece.style.left = Math.random() * 100 + "%";
    piece.style.background = colors[i % colors.length];
    piece.style.animationDuration = 2 + Math.random() * 2 + "s";
    piece.style.animationDelay = Math.random() * 0.6 + "s";
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    zone.appendChild(piece);
  }
  setTimeout(() => (zone.innerHTML = ""), 4500);
}

/* ------------------------------ LEADERBOARD --------------------------------- */
function saveToLeaderboard(score, accuracy, seconds) {
  const list = JSON.parse(localStorage.getItem(LS_LEADERBOARD) || "[]");
  list.push({
    name: state.playerName,
    score,
    accuracy,
    seconds,
    date: new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }),
  });
  list.sort((a, b) => b.score - a.score || a.seconds - b.seconds);
  localStorage.setItem(LS_LEADERBOARD, JSON.stringify(list.slice(0, 20)));
}

function renderLeaderboard() {
  const list = JSON.parse(localStorage.getItem(LS_LEADERBOARD) || "[]");
  const body = document.getElementById("leaderboardBody");
  const empty = document.getElementById("leaderboardEmpty");
  body.innerHTML = "";
  if (!list.length) {
    empty.hidden = false;
    return;
  }
  empty.hidden = true;
  list.forEach((entry, i) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${i + 1}</td>
      <td>${escapeHtml(entry.name)}</td>
      <td>${entry.score}/20</td>
      <td>${entry.accuracy}%</td>
      <td>${formatTime(entry.seconds)}</td>
      <td>${entry.date}</td>`;
    body.appendChild(tr);
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
