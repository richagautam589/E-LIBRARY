/* ===================================================================
   National Librarian Day 2026 — Quiz Question Bank
   Categories (5 questions each, 20 total):
     resources    -> Library Resources & Their Usage
     persons      -> Important Persons in LIS
     concepts     -> Important Concepts & Advantages
     technology   -> Latest Technology in Libraries
   Question "type": mcq | picture | situation
   =================================================================== */

const CATEGORY_META = {
  resources:  { label: "Resources & Usage",  icon: "📚", tab: "R" },
  persons:    { label: "Important Persons",  icon: "🧑‍🏫", tab: "P" },
  concepts:   { label: "Concepts & Advantages", icon: "💡", tab: "C" },
  technology: { label: "Latest Technology",  icon: "🚀", tab: "T" },
};

/* ---- inline SVG icons used for "identify the picture" questions ---- */
const ICONS = {
  barcode: `
    <svg viewBox="0 0 200 140" xmlns="http://www.w3.org/2000/svg" class="q-illustration">
      <rect x="10" y="10" width="180" height="120" rx="10" fill="var(--card)" stroke="var(--border)" stroke-width="2"/>
      <g transform="translate(30,30)">
        <rect x="0"  y="0" width="4" height="60" fill="currentColor"/>
        <rect x="8"  y="0" width="2" height="60" fill="currentColor"/>
        <rect x="14" y="0" width="6" height="60" fill="currentColor"/>
        <rect x="24" y="0" width="2" height="60" fill="currentColor"/>
        <rect x="30" y="0" width="4" height="60" fill="currentColor"/>
        <rect x="38" y="0" width="8" height="60" fill="currentColor"/>
        <rect x="50" y="0" width="2" height="60" fill="currentColor"/>
        <rect x="56" y="0" width="4" height="60" fill="currentColor"/>
        <rect x="64" y="0" width="6" height="60" fill="currentColor"/>
        <rect x="74" y="0" width="2" height="60" fill="currentColor"/>
        <rect x="80" y="0" width="4" height="60" fill="currentColor"/>
        <rect x="88" y="0" width="8" height="60" fill="currentColor"/>
        <rect x="100" y="0" width="2" height="60" fill="currentColor"/>
        <rect x="106" y="0" width="6" height="60" fill="currentColor"/>
        <rect x="116" y="0" width="4" height="60" fill="currentColor"/>
        <rect x="124" y="0" width="2" height="60" fill="currentColor"/>
        <rect x="130" y="0" width="8" height="60" fill="currentColor"/>
        <text x="70" y="80" font-family="JetBrains Mono, monospace" font-size="13" fill="currentColor" text-anchor="middle">978-3-16-148410-0</text>
      </g>
    </svg>`,
  rfid: `
    <svg viewBox="0 0 200 140" xmlns="http://www.w3.org/2000/svg" class="q-illustration">
      <rect x="10" y="10" width="180" height="120" rx="10" fill="var(--card)" stroke="var(--border)" stroke-width="2"/>
      <rect x="50" y="35" width="100" height="70" rx="8" fill="none" stroke="currentColor" stroke-width="2.5"/>
      <circle cx="100" cy="70" r="6" fill="currentColor"/>
      <path d="M100 70 a16 16 0 0 1 16 -16" fill="none" stroke="currentColor" stroke-width="2.5"/>
      <path d="M100 70 a26 26 0 0 1 26 -26" fill="none" stroke="currentColor" stroke-width="2.5"/>
      <path d="M100 70 a16 16 0 0 0 -16 16" fill="none" stroke="currentColor" stroke-width="2.5"/>
      <path d="M100 70 a26 26 0 0 0 -26 26" fill="none" stroke="currentColor" stroke-width="2.5"/>
      <line x1="66" y1="90" x2="134" y2="90" stroke="currentColor" stroke-width="1.5" stroke-dasharray="3 3"/>
      <text x="100" y="120" font-family="JetBrains Mono, monospace" font-size="11" fill="currentColor" text-anchor="middle">TAG · 013F92</text>
    </svg>`,
  qr: `
    <svg viewBox="0 0 200 140" xmlns="http://www.w3.org/2000/svg" class="q-illustration">
      <rect x="10" y="10" width="180" height="120" rx="10" fill="var(--card)" stroke="var(--border)" stroke-width="2"/>
      <g transform="translate(58,22)" fill="currentColor">
        <rect x="0" y="0" width="24" height="24"/><rect x="6" y="6" width="12" height="12" fill="var(--card)"/>
        <rect x="60" y="0" width="24" height="24"/><rect x="66" y="6" width="12" height="12" fill="var(--card)"/>
        <rect x="0" y="60" width="24" height="24"/><rect x="6" y="66" width="12" height="12" fill="var(--card)"/>
        <rect x="30" y="0" width="8" height="8"/><rect x="42" y="0" width="8" height="8"/>
        <rect x="30" y="12" width="8" height="8"/><rect x="0" y="30" width="8" height="8"/>
        <rect x="12" y="30" width="8" height="8"/><rect x="30" y="30" width="8" height="8"/>
        <rect x="42" y="30" width="8" height="8"/><rect x="60" y="30" width="8" height="8"/>
        <rect x="72" y="30" width="8" height="8"/><rect x="30" y="42" width="8" height="8"/>
        <rect x="42" y="54" width="8" height="8"/><rect x="60" y="54" width="8" height="8"/>
        <rect x="30" y="66" width="8" height="8"/><rect x="42" y="66" width="8" height="8"/>
        <rect x="54" y="66" width="8" height="8"/><rect x="66" y="66" width="8" height="8"/>
        <rect x="78" y="66" width="8" height="8"/>
      </g>
    </svg>`,
};

const QUESTIONS = [
  /* ---------------------------- RESOURCES ---------------------------- */
  {
    id: "res-1", category: "resources", type: "mcq",
    q: "A patron wants a brief, reliable factual summary of a topic — key dates, definitions, an overview. Which resource should they consult first?",
    options: ["Encyclopedia", "Novel", "Doctoral thesis", "Atlas"],
    correct: "Encyclopedia",
    explanation: "Encyclopedias are tertiary reference sources designed to give a concise, factual overview of a topic — ideal for a quick, reliable starting point before deeper research.",
  },
  {
    id: "res-2", category: "resources", type: "situation",
    q: "Situation: A researcher needs the full text of a journal article, but your library does not subscribe to that journal. What is the correct professional solution?",
    options: ["Request it through Interlibrary Loan (ILL)", "Ask a colleague to photocopy it from another library informally", "Search for a pirated PDF online", "Tell the researcher it cannot be obtained"],
    correct: "Request it through Interlibrary Loan (ILL)",
    explanation: "Interlibrary Loan (ILL) is the formal, legal cooperative service that lets a library borrow or obtain copies of material from another library on behalf of its patrons.",
  },
  {
    id: "res-3", category: "resources", type: "picture",
    q: "Identify the picture: This symbol is printed on the back cover of nearly every published book. What is it used for?",
    image: ICONS.barcode,
    options: ["Unique identification of the book (ISBN)", "The author's digital signature", "The patron's library card number", "A price tag only, with no other function"],
    correct: "Unique identification of the book (ISBN)",
    explanation: "The scannable barcode encodes the ISBN (International Standard Book Number), a unique identifier used worldwide for cataloguing, ordering, and circulation.",
  },
  {
    id: "res-4", category: "resources", type: "mcq",
    q: "Which of the following is an example of a primary source?",
    options: ["A diary written by a historical figure during the event", "A textbook summarizing the historical period", "An encyclopedia entry about the event", "A biography written 100 years later"],
    correct: "A diary written by a historical figure during the event",
    explanation: "Primary sources are firsthand, original accounts created at the time of the event (diaries, letters, photographs). Textbooks, encyclopedias, and later biographies are secondary or tertiary sources.",
  },
  {
    id: "res-5", category: "resources", type: "mcq",
    q: "What does a library's Institutional Repository (IR) typically store?",
    options: ["The institution's own research output — theses, papers, and datasets", "Only popular fiction titles", "Printed newspapers from the current week", "Staff attendance and payroll records"],
    correct: "The institution's own research output — theses, papers, and datasets",
    explanation: "An Institutional Repository is a digital archive that collects, preserves, and provides open access to the scholarly output produced by members of an institution.",
  },

  /* ----------------------------- PERSONS ------------------------------ */
  {
    id: "per-1", category: "persons", type: "mcq",
    q: "Who is regarded as the 'Father of Library Science' and formulated the Five Laws of Library Science?",
    options: ["Dr. S. R. Ranganathan", "Melvil Dewey", "Charles Ammi Cutter", "Antonio Panizzi"],
    correct: "Dr. S. R. Ranganathan",
    explanation: "Dr. Shiyali Ramamrita Ranganathan, an Indian mathematician and librarian, is celebrated as the father of library science for his Five Laws (1931) and the Colon Classification system.",
  },
  {
    id: "per-2", category: "persons", type: "mcq",
    q: "Melvil Dewey is best known in library history for developing which system?",
    options: ["Dewey Decimal Classification (DDC)", "Library of Congress Classification (LCC)", "Universal Decimal Classification (UDC)", "Colon Classification (CC)"],
    correct: "Dewey Decimal Classification (DDC)",
    explanation: "Melvil Dewey introduced the Dewey Decimal Classification in 1876, one of the world's most widely used library classification systems, organizing knowledge into ten main classes.",
  },
  {
    id: "per-3", category: "persons", type: "mcq",
    q: "S. R. Ranganathan's Colon Classification is historically significant for introducing which concept to classification theory?",
    options: ["Facet analysis (analytico-synthetic classification)", "The barcode", "RFID-based cataloguing", "The ISBN numbering system"],
    correct: "Facet analysis (analytico-synthetic classification)",
    explanation: "The Colon Classification (1933) pioneered facet analysis — building a subject's classification number from separate facets (Personality, Matter, Energy, Space, Time) rather than a fixed enumerated list.",
  },
  {
    id: "per-4", category: "persons", type: "situation",
    q: "Situation: A 19th-century American cataloguer is credited with early 'rules for a dictionary catalogue' that influenced modern cataloguing codes such as AACR2. Who was he?",
    options: ["Charles Ammi Cutter", "S. R. Ranganathan", "Paul Otlet", "Melvil Dewey"],
    correct: "Charles Ammi Cutter",
    explanation: "Charles Ammi Cutter's 'Rules for a Dictionary Catalog' (1876) laid foundational cataloguing principles that shaped later codes, including AACR2 and modern descriptive cataloguing.",
  },
  {
    id: "per-5", category: "persons", type: "mcq",
    q: "Belgian bibliographer Paul Otlet, creator of the Mundaneum, is often called an early visionary of which modern concept?",
    options: ["The interconnected, searchable web of information (a forerunner of the internet)", "The self-checkout kiosk", "The barcode scanner", "The library RFID gate"],
    correct: "The interconnected, searchable web of information (a forerunner of the internet)",
    explanation: "Paul Otlet's early-20th-century vision of a globally networked, searchable body of knowledge is widely seen as a conceptual forerunner of the World Wide Web.",
  },

  /* --------------------------- CONCEPTS -------------------------------- */
  {
    id: "con-1", category: "concepts", type: "mcq",
    q: "Which of the following is NOT one of S. R. Ranganathan's Five Laws of Library Science?",
    options: ["Every library its profit", "Books are for use", "Every reader his/her book", "Save the time of the reader"],
    correct: "Every library its profit",
    explanation: "The genuine Five Laws are: 1) Books are for use, 2) Every reader his/her book, 3) Every book its reader, 4) Save the time of the reader, 5) A library is a growing organism. Profit is not part of them.",
  },
  {
    id: "con-2", category: "concepts", type: "mcq",
    q: "In library and information science, what does the term 'metadata' mean?",
    options: ["Structured data that describes other data (e.g. title, author, subject)", "Only the physical shelf location of an item", "A category of overdue fine", "The retail price printed on a book"],
    correct: "Structured data that describes other data (e.g. title, author, subject)",
    explanation: "Metadata is 'data about data' — structured information such as title, author, subject headings, and format that helps describe, identify, and retrieve a resource.",
  },
  {
    id: "con-3", category: "concepts", type: "mcq",
    q: "What does 'Open Access' (OA) mean in scholarly publishing?",
    options: ["Free, immediate online access to research, largely free of copyright/licensing restrictions", "Access granted only to paying institutional members", "Physical access to a library's open stacks", "Access restricted to the original authors only"],
    correct: "Free, immediate online access to research, largely free of copyright/licensing restrictions",
    explanation: "Open Access removes price and permission barriers so anyone, anywhere, can freely read, download, and (usually) reuse scholarly research online.",
  },
  {
    id: "con-4", category: "concepts", type: "situation",
    q: "Situation: A library wants users to access its collection and services 24/7, regardless of the user's physical location. Which model best fulfils this need?",
    options: ["A digital library", "A reference-only reading room", "A closed-stack library", "A mobile library van visiting once a week"],
    correct: "A digital library",
    explanation: "Digital libraries provide anytime, anywhere access to digitized and born-digital resources over the internet, overcoming the time and location limits of a physical building.",
  },
  {
    id: "con-5", category: "concepts", type: "mcq",
    q: "Compared to a barcode system, what is a key advantage of RFID in library circulation?",
    options: ["Multiple items can be checked out/in simultaneously without line-of-sight scanning", "RFID tags are always cheaper than printed barcodes", "RFID tags need no power source at any stage", "RFID tags can only store a book's title"],
    correct: "Multiple items can be checked out/in simultaneously without line-of-sight scanning",
    explanation: "RFID tags can be read in bulk and without a direct line of sight, allowing an entire stack of books to be checked out or inventoried at once — a major speed advantage over barcodes.",
  },

  /* --------------------------- TECHNOLOGY ------------------------------ */
  {
    id: "tech-1", category: "technology", type: "picture",
    q: "Identify the picture: This small embedded chip-and-antenna tag is attached inside books for tracking and self-checkout. What technology is it?",
    image: ICONS.rfid,
    options: ["RFID Tag", "Barcode label", "QR Code", "Wi-Fi router"],
    correct: "RFID Tag",
    explanation: "RFID (Radio-Frequency Identification) tags use a chip and antenna to transmit data wirelessly, enabling fast self-checkout, security gates, and bulk shelf-inventory scanning.",
  },
  {
    id: "tech-2", category: "technology", type: "mcq",
    q: "How do AI-powered chatbots mainly help library users today?",
    options: ["By answering FAQs and guiding users to resources instantly, day or night", "By permanently replacing all librarians", "By physically printing books on demand", "By repairing library shelving"],
    correct: "By answering FAQs and guiding users to resources instantly, day or night",
    explanation: "Library chatbots provide round-the-clock instant answers to common questions (hours, renewals, resource locations), freeing librarians to focus on complex reference and instruction work.",
  },
  {
    id: "tech-3", category: "technology", type: "picture",
    q: "Identify the picture: Patrons scan this square pattern with a phone camera outside an exhibit or on a poster to instantly open extra information online. What is it?",
    image: ICONS.qr,
    options: ["QR Code", "ISBN Barcode", "RFID chip", "Library seal"],
    correct: "QR Code",
    explanation: "A QR (Quick Response) code is a 2D matrix barcode that phone cameras can scan instantly to open a link — widely used in libraries for exhibit info, digital guides, and catalog shortcuts.",
  },
  {
    id: "tech-4", category: "technology", type: "mcq",
    q: "What is a major benefit of a cloud-based Library Management System (LMS)?",
    options: ["Staff can access and update it from anywhere, without heavy local IT infrastructure", "It only functions when the internet is switched off", "It removes the need for a catalog entirely", "It eliminates the need for any library staff"],
    correct: "Staff can access and update it from anywhere, without heavy local IT infrastructure",
    explanation: "Cloud-based LMS platforms are hosted remotely, so libraries avoid maintaining costly local servers while staff can manage circulation, cataloguing, and reports from any connected device.",
  },
  {
    id: "tech-5", category: "technology", type: "situation",
    q: "Situation: Your library wants to cut checkout queues during exam season without hiring extra staff. Which technology fits best?",
    options: ["Self-checkout kiosks with RFID/barcode scanning", "Adding more paper issue-return registers", "Removing the circulation desk entirely", "Increasing overdue fines to discourage borrowing"],
    correct: "Self-checkout kiosks with RFID/barcode scanning",
    explanation: "Self-checkout kiosks let patrons issue and return items themselves in seconds, dramatically cutting queues at peak times without adding staff headcount.",
  },
];

/* Fisher–Yates shuffle — used for both question order and options */
function shuffleArray(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* Build a fresh, randomized quiz run: shuffled question order + shuffled options per question */
function buildShuffledQuiz() {
  const shuffledQuestions = shuffleArray(QUESTIONS);
  return shuffledQuestions.map((q) => ({
    ...q,
    options: shuffleArray(q.options),
  }));
}
