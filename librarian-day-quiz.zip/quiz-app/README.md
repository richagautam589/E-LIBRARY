# The Stacks & The Screen — National Librarian Day Quiz 2026

A 20-question interactive Library & Information Science quiz built for
**National Librarian Day, 12 August 2026**.

## What's inside
- `index.html` — the app
- `css/style.css` — all styling (light "Reading Room" + dark "OPAC Terminal" themes)
- `js/questions.js` — the 20-question bank (4 sections × 5 questions) + shuffle logic
- `js/app.js` — quiz engine: timer, scoring, progress, leaderboard, animations

No build step, no external accounts, no server required — it's a static site.

## Publish it on GitHub Pages (step by step)

1. **Create a new repository** on GitHub (e.g. `librarian-day-quiz`). Keep it Public.
2. **Upload the contents of this ZIP** — not the ZIP itself — to the repository:
   - On the repo page, click **"Add file" → "Upload files"**.
   - Drag in `index.html`, the `css` folder, and the `js` folder (and this `README.md`)
     so they sit at the **root** of the repository.
   - Click **Commit changes**.
3. **Turn on GitHub Pages**:
   - Go to **Settings → Pages**.
   - Under "Build and deployment", set **Source** to **Deploy from a branch**.
   - Set **Branch** to `main` (or `master`) and folder to **/ (root)**. Click **Save**.
4. Wait about a minute, then refresh the Pages settings page — a green banner will
   show your live link, something like:
   `https://<your-username>.github.io/librarian-day-quiz/`
5. Share that link with your users. 🎉

## Notes
- Questions and answer options are reshuffled every time someone starts (or retries)
  the quiz, so no two attempts look the same.
- The leaderboard is stored in each visitor's own browser (`localStorage`) — it is
  personal to their device, not a shared/global leaderboard across all users.
- Toggle light/dark mode with the switch in the top-right header.
- Works on desktop and mobile; no internet connection is needed after the page and
  its two Google Fonts load once.

---
© 2026 Richa · richa@invertis.org · +91 7078970823
